# Image_Recognition
Machine learning model which will detect whether a person is wearing sunglasses or not and in which direction is he/she looking
